# gestor_asistencias
En este repositorio se subirán todos los cambios del proyecto de asistencias creado con Django
